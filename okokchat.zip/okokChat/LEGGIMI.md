Ciao, grazie per aver usato il mio script, te ne sono grato!

Se hai bisogno di aiuto contattami su discord: TrentaSei#0001

1. Disabilita lo script della chat che stai utilizzando attualmente

2. Come mettere la chat al lato destro
	Nello styles.css alla linea 22 cambia 'left: 40px;' in 'right: 40px;' e fai la stessa cosa nella linea 42

3. Come aggiungere i messaggi di sistema a ESX
	Recati in es_extended/server/main.lua e cerca le seguenti stringhe di codice:

	AddEventHandler('chatMessage', function(playerId, author, message)
		if message:sub(1, 1) == '/' and playerId > 0 then
			CancelEvent()
			local commandName = message:sub(1):gmatch("%w+")()
			TriggerClientEvent('chat:addMessage', playerId, {args = {'^1SYSTEM', _U('commanderror_invalidcommand', commandName)}})
		end
	end)

	E rimpiazzale con:

	AddEventHandler('chatMessage', function(playerId, author, message)
		local time = os.date('%H:%M')

		if message:sub(1, 1) == '/' and playerId > 0 then
			CancelEvent()
			local commandName = message:sub(1):gmatch("%w+")()

			TriggerClientEvent('chat:addMessage', playerId, {
		    template = '<div class="chat-message system"><i class="fas fa-cog"></i> <b><span style="color: #df7b00">SYSTEM</span>&nbsp;<span style="font-size: 14px; color: #e1e1e1;">{1}</span></b><div style="margin-top: 5px; font-weight: 300;"><b>{0}</b> is not a valid command!</div></div>',
		    args = { commandName, time }
		})
		end
	end)
