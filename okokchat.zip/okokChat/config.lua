Config = {}
--------------------------------
-- [Date Format]

Config.DateFormat = '%H:%M' -- To change the date format check this website - https://www.lua.org/pil/22.1.html

-- [Staff Groups]

Config.StaffGroups = {
	'superadmin',
	'admin',
	'mod'
}

--------------------------------
-- [Clear Player Chat]

Config.AllowPlayersToClearTheirChat = true

Config.ClearChatCommand = 'clear'

--------------------------------
-- [Staff]

Config.EnableStaffCommand = true

Config.StaffCommand = 'staff'

Config.AllowStaffsToClearEveryonesChat = true

Config.ClearEveryonesChatCommand = 'clearall'

-- [Staff Only Chat]

Config.EnableStaffOnlyCommand = true

Config.StaffOnlyCommand = 'staffo'

--------------------------------
-- [Advertisements]

Config.EnableAdvertisementCommand = true

Config.AdvertisementCommand = 'ad'

Config.AdvertisementPrice = 1000

Config.AdvertisementCooldown = 5 -- in minutes

--------------------------------
-- [Twitch]

Config.EnableTwitchCommand = true

Config.TwitchCommand = 'twitch'

-- Tipi di ID utilizzabili: steam: | license: | xbl: | live: | discord: | fivem: | ip:
Config.TwitchList = {
	'license:ec3bPaR24c0bbcFe4b4dfb8a71646cdc1873670ec' -- Esempio, Cambialo per avere i permessi in game
}

--------------------------------
-- [Youtube]

Config.EnableYoutubeCommand = true

Config.YoutubeCommand = 'youtube'

-- Tipi di ID utilizzabili: steam: | license: | xbl: | live: | discord: | fivem: | ip:
Config.YoutubeList = {
	'license:ec3bPaR24c0bbcFe4b4dfb8a71646cdc1873670ec' -- Esempio, Cambialo per avere i permessi in game
}

--------------------------------
--------------------------------
-- [Owner]

Config.EnableOwnerCommand = true

Config.OwnerCommand = 'owner'

-- Tipi di ID utilizzabili: steam: | license: | xbl: | live: | discord: | fivem: | ip:
Config.OwnerList = {
	'license:ec3bPaR24c0bbcFe4b4dfb8a71646cdc1873670ec' -- Esempio, Cambialo per avere i permessi in game
}

--------------------------------
-- [Twitter]

Config.EnableTwitterCommand = false

Config.TwitterCommand = 'twitter'

--------------------------------
-- [Azione]

Config.EnableAzioneCommand = true

Config.AzioneCommand = 'azione'

--------------------------------
-- [Anonimo]

Config.EnableAnonimoCommand = true

Config.AnonimoCommand = 'anonimo'

--------------------------------
-- [Cercolavoro]

Config.EnableCercolavoroCommand = true

Config.CercolavoroCommand = 'cercolavoro'

--------------------------------

--------------------------------
-- [Police]

Config.EnablePoliceCommand = true

Config.PoliceCommand = 'police'

Config.PoliceJobName = 'police'

--------------------------------
-- [Ambulance]

Config.EnableAmbulanceCommand = true

Config.AmbulanceCommand = 'ambulance'

Config.AmbulanceJobName = 'ambulance'

--------------------------------
-- [OOC]

Config.EnableOOCCommand = false

Config.OOCCommand = 'ooc'

Config.OOCDistance = 20.0

--------------------------------